<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Moonlight 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20110815

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Blue Lunar Quartet</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="header" class="container">
		<div id="logo">
			<h1><a href="#">Blue Lunar Quartet</a></h1>
			<p>a jazz quartet in Raleigh, NC</p>
		</div>
		<div id="menu">
			<ul>
			<?php
				$requested = $_REQUEST['p'];
				if (! isset($_REQUEST['p']))
					$requested="home";
					
				$pageurls = array("home", "dates", "photos");
				
				foreach ($pageurls as $url)
				{
					if ($url == $requested)
					{
						echo "<li class='current_page_item'><a href='?p=" . $url . "'>" . $url . "</a>";
					}
					else
					{
						echo "<li><a href='?p=" . $url . "'>" . $url . "</a>";
					}
				}
			?>
			</ul>
		</div>
	</div>
	<!-- end #header -->
	<div id="page">
		<div id="content">
		<?php
		
		$pagenames = array("home", "dates", "photos");
		$requested = $_REQUEST['p'];
		
		if (in_array($requested, $pagenames))
		{
			include $requested . ".html";
		}
		else
		{
			include "home.html";
		}
		
		?>
		<!-- end #content -->
		<div id="sidebar">
			<ul>
				<li>
					<h2>Latest Music</h2>
					<p>Check out our latest recordings here
					<object type="application/x-shockwave-flash" width="215" height="15" data="http://bluelunar.zapto.org/xspf_player_slim.swf?playlist_url=http://bluelunar.zapto.org/playlist.xspf&player_title=Listen+to+Blue+Lunar+Quartet">
					<param name="movie" value="http://bluelunar.zapto.org/xspf_player_slim.swf?playlist_url=http://bluelunar.zapto.org/playlist.xspf&player_title=Listen+to+Blue+Lunar+Quartet" />
					</object></p>
				</li>
				<li>
					<h2>Contact</h2>
					<p>
					<a href="https://www.facebook.com/BlueLunarQuartet">Facebook</a> | 
					<a href="mailto:bluelunar@bluelunar.zapto.org">E-mail</a> | 
					<a href="http://twitter.com/#!/bluelunar4">Twitter</a>
					</p>
				</li>
				<li>
					<h2>About Us</h2>
					<p>
					The Blue Lunar Quartet is a jazz ensemble featuring four musicians from Raleigh, NC:<br />
					<p>Carter Harris - Sax<br />
					Chad Mangum - Drums<br />
					Andy Powell - Bass<br />
					Ben Smith - Piano<br />
					</p>
				</li>
			</ul>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>

<div id="footer">
	<p>Copyright &copy;2012 Blue Lunar Quartet, Ben Smith, Carter Harris, Andy Powell, Chad Mangum. All rights reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
</div>
<!-- end #footer -->
</body>
</html>
